# FLIMAnalyzer

Package for analsis of Fluoresence Life-time Microscopy (FLIM) data.
